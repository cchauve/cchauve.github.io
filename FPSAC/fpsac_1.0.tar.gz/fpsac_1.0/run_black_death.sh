./fpsac.sh \
    black_death/final \
    black_death/data/yersinia_species_tree \
    black_death/data/8291_assembled_contigs.fa \
    black_death/data/yersinia_pestis_pseudotuberculosis.fa \
    100 \
    95 \
    5 \
    Black_Death_Agent_8291
