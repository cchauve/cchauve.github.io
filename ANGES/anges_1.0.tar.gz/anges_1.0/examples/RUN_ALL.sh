# ANGES 1.0, reconstruction ANcestral GEnomeS maps
# May 2012.
# Contact: Cedric Chauve (Dept. Mathematics, Simon Fraser University), cedric.chauve@sfu.ca

# This script runs all examples, and illustrates a wide set of models
# and algorithms of reconstrucion of ancestral genome maps available
# in ANGES.

cd fungal_genomes/
python ../../src/MASTER/anges_CAR.py PARAMETERS_TEL_BAB
python ../../src/MASTER/anges_CAR.py PARAMETERS_TEL_HEUR
python ../../src/MASTER/anges_CAR.py PARAMETERS_SERIATION
cd ../mammalian_genomes/
python ../../src/MASTER/anges_CAR.py PARAMETERS_OUANGRAOUA_ET_AL_2011_AMNIOTE_TEL_BAB
python ../../src/MASTER/anges_CAR.py PARAMETERS_OUANGRAOUA_ET_AL_2011_BOREOEUTHERIAN_SERIATION
python ../../src/MASTER/anges_CAR.py PARAMETERS_OUANGRAOUA_ET_AL_2011_BOREOEUTHERIAN_TEL_HEUR
python ../../src/MASTER/anges_CAR.py PARAMETERS_MA_ET_AL_2006_BOREOEUTHERIAN_HEUR
python ../../src/MASTER/anges_CAR.py PARAMETERS_MA_ET_AL_2006_BOREOEUTHERIAN_SERIATION
python ../../src/MASTER/anges_CAR.py PARAMETERS_GAVRANOVIC_ET_AL_2011_SERIATION
cd ../bacterial_genomes/
python ../../src/MASTER/anges_CAR.py PARAMETERS_BURKHOLDERIA_1
python ../../src/MASTER/anges_CAR.py PARAMETERS_BURKHOLDERIA_2
cd ../plant_genomes/
python ../../src/MASTER/anges_CAR.py PARAMETERS_MONOCOTS
cd ../


